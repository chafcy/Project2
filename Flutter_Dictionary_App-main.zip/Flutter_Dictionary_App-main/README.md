#Simple Dictionary App 
API USED : http://api.dictionaryapi.dev

Library USED : http





![Screenshot 2023-11-26 at 12 25 15](https://github.com/bimalkaf/Flutter_Dictionary_App/assets/60041910/60db0b3a-4666-4c57-a414-0d70a77a0323)
